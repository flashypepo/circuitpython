from adafruit_lis3dh.lis3dh import *
