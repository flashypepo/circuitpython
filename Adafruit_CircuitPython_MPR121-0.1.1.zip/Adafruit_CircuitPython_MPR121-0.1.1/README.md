# Adafruit CircuitPython MPR121
Adafruit CircuitPython module for the MPR121 capacitive touch breakout board.
Note this module is currently made to work with CircuitPython and not upstream
MicroPython!

This module depends on the Adafruit Bus Device module being installed on the
board: https://github.com/adafruit/Adafruit_CircuitPython_BusDevice
