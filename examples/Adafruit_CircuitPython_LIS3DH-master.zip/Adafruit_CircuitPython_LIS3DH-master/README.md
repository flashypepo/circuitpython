# Adafruit CircuitPython LIS3DH

Adafruit CircuitPython module for the LIS3DH accelerometer.  Note this module
is currently made to work with CircuitPython and not MicroPython APIs.  See the guide at:
https://learn.adafruit.com/circuitpython-hardware-lis3dh-accelerometer
